<?php
// Запрет прямого доступа.
defined('_JEXEC') or die;

// Подключаем библиотеку контроллера Joomla.
jimport('joomla.application.component.controller');

/**
 * Контроллер компонента News.
 */
class NewsController extends JControllerLegacy
{
}
